import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(DecorFormApp());

class DecorFormApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: DecorFormPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class DecorFormPage extends StatefulWidget {
  @override
  _DecorFormPageState createState() => _DecorFormPageState();
}

class _DecorFormPageState extends State<DecorFormPage> {
  final _formKey = GlobalKey<FormState>();
  String fullName = '';
  String phone = '';
  String decorType = 'أسقف جبس';
  String location = '';
  String area = '';
  String notes = '';

  final List<String> decorOptions = [
    'أسقف جبس',
    'دهان',
    'ورق جدران',
    'أرضيات',
    'إضاءة',
    'أخرى',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('استمارة زبائن الديكور')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                TextFormField(
                  decoration: InputDecoration(labelText: 'الاسم الكامل'),
                  onSaved: (value) => fullName = value!,
                  validator: (value) => value!.isEmpty ? 'مطلوب' : null,
                ),
                TextFormField(
                  decoration: InputDecoration(labelText: 'رقم الهاتف'),
                  keyboardType: TextInputType.phone,
                  onSaved: (value) => phone = value!,
                  validator: (value) => value!.isEmpty ? 'مطلوب' : null,
                ),
                DropdownButtonFormField<String>(
                  decoration: InputDecoration(labelText: 'نوع الديكور المطلوب'),
                  value: decorType,
                  items: decorOptions
                      .map((type) => DropdownMenuItem(
                            value: type,
                            child: Text(type),
                          ))
                      .toList(),
                  onChanged: (value) => setState(() => decorType = value!),
                ),
                TextFormField(
                  decoration: InputDecoration(labelText: 'الموقع (العنوان)'),
                  onSaved: (value) => location = value!,
                  validator: (value) => value!.isEmpty ? 'مطلوب' : null,
                ),
                TextFormField(
                  decoration: InputDecoration(labelText: 'المساحة بالمتر المربع (اختياري)'),
                  keyboardType: TextInputType.number,
                  onSaved: (value) => area = value ?? '',
                ),
                TextFormField(
                  decoration: InputDecoration(labelText: 'ملاحظات إضافية'),
                  maxLines: 3,
                  onSaved: (value) => notes = value ?? '',
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  child: Text('إرسال'),
                  onPressed: () async {
                    if (_formKey.currentState!.validate()) {
                      _formKey.currentState!.save();
                      final message = '''
الاسم: $fullName
رقم الهاتف: $phone
نوع الديكور: $decorType
الموقع: $location
المساحة: $area
ملاحظات: $notes
''';
                      final url = 'https://wa.me/963992642312?text=${Uri.encodeComponent(message)}';
                      if (await canLaunch(url)) {
                        await launch(url);
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('تعذر فتح واتساب')),
                        );
                      }
                    }
                  },
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}